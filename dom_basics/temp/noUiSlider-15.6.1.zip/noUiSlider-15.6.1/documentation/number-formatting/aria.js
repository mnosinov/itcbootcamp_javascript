noUiSlider.create(slider, {
    /* ... */
    ariaFormat: wNumb({
        decimals: 3
    }),
});
